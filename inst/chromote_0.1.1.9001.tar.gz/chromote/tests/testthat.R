library(testthat)
library(chromote)

test_check("chromote")
